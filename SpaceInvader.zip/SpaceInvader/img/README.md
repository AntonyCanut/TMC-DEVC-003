README:

Nommage des fichiers:

NOM_HauteurxLargeur1_P_Largeur2.png

exemple_600x3600_P_600.png

Hauteur: hauteur de l'image

Largeur1: largeur total de l'image

Largeur2: largeurdu pas ou de chaque image
